1. I (James) worked on steps 1-6. Molly worked on step 6.

2. These steps can be verified by compiling the project with the shell script and running it in the simulator. Typing "exec number" in the command line will start the number program but the shell will still be running alongside it, meaning that multiple processes can be run at the same time. Typing "kill 1" will terminate process 1, making the process not be scheduled again.
